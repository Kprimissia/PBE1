package prjExercicio2;

public class Livro {


	// Atributos
	
	String atributoTitulo;
	String atributoAutor;
	int atributoNumPaginas;
	double atributoPreco;
	
	// Construtores
	
	public Livro() {
	}
	
	public Livro(String parametroTitulo, String parametroAutor,int parametroNumPaginas, int parametroPreco ) {
		
			this.atributoTitulo = parametroTitulo;
			this.atributoAutor = parametroAutor;
			this.atributoNumPaginas = parametroNumPaginas;
			this.atributoPreco = parametroPreco; 
	}
	
	// Metodos
	
	public void aplicarDesconto() {
		if(this.atributoPreco == atributoPreco) {
			System.out.println(this.atributoPreco + " , desconto");
		}
		
		else {
			this.atributoPreco -= 15;
		}
	}
	
	public void exibirInfo() {
		System.out.println(this.atributoTitulo + this.atributoAutor + this.atributoNumPaginas + this.atributoPreco);
	}

	public String getAtributoTitulo() {
		return atributoTitulo;
	}

	public void setAtributoTitulo(String atributoTitulo) {
		this.atributoTitulo = atributoTitulo;
	}

	public String getAtributoAutor() {
		return atributoAutor;
	}

	public void setAtributoAutor(String atributoAutor) {
		this.atributoAutor = atributoAutor;
	}

	public int getAtributoNumPaginas() {
		return atributoNumPaginas;
	}

	public void setAtributoNumPaginas(int atributoNumPaginas) {
		this.atributoNumPaginas = atributoNumPaginas;
	}

	public double getAtributoPreco() {
		return atributoPreco;
	}

	public void setAtributoPreco(double atributoPreco) {
		this.atributoPreco = atributoPreco;
	}
	
}


