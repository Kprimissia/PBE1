package prjExercicio2;


public class aplicacao {

	public static void main(String[] args) {

		Livro AsCronicasDeQuintilliano = new Livro();
		AsCronicasDeQuintilliano.atributoTitulo = "Cronicas De Quintilliano";
		AsCronicasDeQuintilliano.atributoAutor = "Julio Tragueiro";
		AsCronicasDeQuintilliano.atributoNumPaginas = 400;
		AsCronicasDeQuintilliano.atributoPreco = 86;
		
		Livro TrigueiroOrwell  = new Livro();
		TrigueiroOrwell.atributoTitulo = "Trigueiro Orwell";
		TrigueiroOrwell.atributoAutor = "Kaiki Snatos";
		TrigueiroOrwell.atributoNumPaginas = 350;
		TrigueiroOrwell.atributoPreco = 85;

		
		Livro DiarioSnatos  = new Livro();
		DiarioSnatos.atributoTitulo = "Diario Snatos";
		DiarioSnatos.atributoAutor = "Primissia";
		DiarioSnatos.atributoNumPaginas = 370;
		DiarioSnatos.atributoPreco = 89;

	}
	

}
