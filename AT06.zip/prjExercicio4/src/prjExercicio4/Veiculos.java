package prjExercicio4;

public class Veiculos {
	//Atributos
	
	String atributoMarca;
	String atributoModelo;
	int atributoVelocidade;
	
	//Construtores
	
	public Veiculos() {
		
	}
	
	public Veiculos(String parametroMarca,String parametroModelo,int parametroVelocidade) {
		this.atributoMarca = parametroMarca;
		this.atributoModelo = parametroModelo;
		this.atributoVelocidade = parametroVelocidade;	

	}
	
	//Metodos
	
	public
	
