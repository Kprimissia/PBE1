package prjExercicio1;

public class Carro {

	// Atributos
	
	String atributoMarca;
	String atributoModelo;
	String atributoPlaca;
	int atributoAno;
	
	// Construtores
	
	public Carro() {
	}
	
	public Carro(String atributoMarca, String parametroModelo,String atributoPlaca, int atributoAno ) {
		
			this.atributoMarca = atributoMarca;
			this.atributoModelo = parametroModelo;
			this.atributoPlaca = atributoPlaca;
			this.atributoAno = atributoAno; 
	}
	
	// Metodos
	
	public void exibirInfo() {
			System.out.println(this.atributoMarca + ", do modelo " + this.atributoModelo + ", de " + this.atributoAno + ", da placa: " + atributoAno );
	}
	
	
}
