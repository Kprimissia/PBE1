package prjExercicio1;

public class aplicacao {

	public static void main(String[] args) {
		// Carros e suas informações

		Carro Chevette = new Carro();
		Chevette.atributoMarca = "Chavette";
		Chevette.atributoModelo = "Chevrolet";
		Chevette.atributoPlaca = "AAAA";
		Chevette.atributoAno = 1987;
		
		Carro GolQuadrado = new Carro();
		GolQuadrado.atributoMarca = "Gol Quadrado";
		GolQuadrado.atributoModelo = "Volswagen";
		GolQuadrado.atributoPlaca = "BBB";
		GolQuadrado.atributoAno = 1994;

	}

}
