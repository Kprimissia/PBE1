package prjExercicio3;
	
public class Animal {
	
	//Atributos 
	String atributoNome;
	String atributoIdade;
	String atributoRaca;
	
	//Construtores
	
	public Animal() {
	}
	
	public Animal(String parametroNome, String parametroIdade, String parametroRaca) {
		this.atributoNome = parametroNome;
		this.atributoIdade = parametroIdade;
		this.atributoRaca = parametroRaca;
	}
	
	//Metodos
	
	public void emitirSom() {
		System.out.println(this.atributoNome + ", emitiu um som!!");
	}
	public void metodoCacar() {
		System.out.println(this.atributoNome + ", caçou!!");
	}
	public void metodoNadar() {
	System.out.println(this.atributoNome + ", nadou!!");
	}
	
	
}