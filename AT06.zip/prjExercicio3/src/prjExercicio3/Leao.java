package prjExercicio3;

public class Leao extends Animal {

	//Metodos da Subclasse
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando!");
	}
	
	
	
}