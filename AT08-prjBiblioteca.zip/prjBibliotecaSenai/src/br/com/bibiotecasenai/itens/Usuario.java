package br.com.bibiotecasenai.itens;

public class Usuario {
	
	private int CPF;
	private int livrosEmprestados;
	public int getCPF() {
		return CPF;
	}
	
	public void setCPF() {
		CPF = CPF;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados() {
		this.livrosEmprestados = livrosEmprestados;
	}
	
}
