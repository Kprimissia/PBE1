package br.com.bibiotecasenai.itens;

public class Aplicacao {

	public static void main(String[] args) {
		Usuario usuario01 = new Usuario();
		usuario01.setCPF();
		usuario01.setLivrosEmprestados();
	}

}
