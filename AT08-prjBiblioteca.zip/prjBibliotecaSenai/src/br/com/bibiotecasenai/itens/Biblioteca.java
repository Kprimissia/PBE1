package br.com.bibiotecasenai.itens;

public class Biblioteca {

	//Atributos
	String Matricula;
	
	//Métodos
	
	public void realizarEmprestismo() {
		
	}
	
	public void realizarEmprestimo() {
		
	}
}