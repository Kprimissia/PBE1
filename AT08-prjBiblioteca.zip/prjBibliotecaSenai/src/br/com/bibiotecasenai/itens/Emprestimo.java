package br.com.bibiotecasenai.itens;

public class Emprestimo {

	//Atributos
	
	private int numeroEmprestimos;
	
	//Metodos
	
	public void emprestarLivros() {
		
	}
	
	public void getEmprestarLivros() {
		
	}
	
	public void devolverLivro() {
		
	}
	
	public void getDevolverLivro() {
		
	}
	
}
